package com.example.riesz.chemicalequationbalancer;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public final static String EXTRA_MESSAGE = "com.example.riesz.chemicalequationbalancer.MESSAGE";
    private Toast toast = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final InputFilter[] noFilter = new InputFilter[]{};
        final InputFilter[] allCaps = new InputFilter[]{new InputFilter.AllCaps()};

        final EditText LHSEditText = (EditText) findViewById(R.id.leftEquation);
        final EditText RHSEditText = (EditText) findViewById(R.id.rightEquation);
        final Button balanceButton = (Button) findViewById(R.id.balance_button);

        LHSEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // nothing
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // nothing
            }

            @Override
            public void afterTextChanged(Editable s) {
                int pos = LHSEditText.getSelectionStart();
                if (pos > 0) {
                    if (s.charAt(pos - 1) == '(' || s.charAt(pos - 1) == ' '
                            || s.charAt(pos - 1) == '+' || Character.isLowerCase(s.charAt(pos - 1))
                            || Character.isDigit(s.charAt(pos - 1))) {
                        LHSEditText.setFilters(allCaps);
                    }
                    else {
                        LHSEditText.setFilters(noFilter);
                    }
                }
                if (pos > 1){
                    if (Character.isLowerCase(s.charAt(pos - 1)) && (s.charAt(pos - 2) == '(' || s.charAt(pos - 2) == ' '
                            || s.charAt(pos - 2) == '+' || Character.isLowerCase(s.charAt(pos - 2))
                            || Character.isDigit(s.charAt(pos - 2)))){
                        String str = s.subSequence(pos - 1, pos).toString().toUpperCase();
                        s.replace(pos - 1, pos, str);
                    }
                }
            }
        });

        RHSEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // nothing
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // nothing
            }

            @Override
            public void afterTextChanged(Editable s) {
                int pos = RHSEditText.getSelectionStart();
                if (pos > 0) {
                    if (s.charAt(pos - 1) == '(' || s.charAt(pos - 1) == ' '
                            || s.charAt(pos - 1) == '+' || Character.isLowerCase(s.charAt(pos - 1))
                            || Character.isDigit(s.charAt(pos - 1))) {
                        RHSEditText.setFilters(allCaps);
                    }
                    else {
                        RHSEditText.setFilters(noFilter);
                    }
                }
                if (pos > 1){
                    if (Character.isLowerCase(s.charAt(pos - 1)) && (s.charAt(pos - 2) == '(' || s.charAt(pos - 2) == ' '
                            || s.charAt(pos - 2) == '+' || Character.isLowerCase(s.charAt(pos - 2))
                            || Character.isDigit(s.charAt(pos - 2)))){
                        String str = s.subSequence(pos - 1, pos).toString().toUpperCase();
                        s.replace(pos - 1, pos, str);
                    }
                }
            }
        });

        RHSEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                boolean handled = false;
                if (actionId == EditorInfo.IME_ACTION_GO) {
                    balanceButton.performClick();
                    handled = true;
                }
                return handled;
            }
        });
    }
    public void getBalancedEquation(View view) {
        Intent intent = new Intent(this, BalanceEquationActivity.class);
        EditText LHSEqn = (EditText) findViewById(R.id.leftEquation);
        EditText RHSEqn = (EditText) findViewById(R.id.rightEquation);
        String equation = LHSEqn.getText().toString() + "=" + RHSEqn.getText().toString(); // string operations in separate class
        try {
            equation = EquationBalance.balanceEquation(equation);
        } catch (Exception e) {
            if (toast != null){
                toast.cancel();
            }
            toast = Toast.makeText(this, "Invalid Equation — Try Again", Toast.LENGTH_SHORT);
            toast.show();
            return;
        }
        intent.putExtra(EXTRA_MESSAGE, equation);
        startActivity(intent);
    }
    public void clearEqn(View view) {
        EditText LHSEqn = (EditText) findViewById(R.id.leftEquation);
        EditText RHSEqn = (EditText) findViewById(R.id.rightEquation);
        LHSEqn.setText("");
        RHSEqn.setText("");
        LHSEqn.requestFocus();
        if (toast != null){
            toast.cancel();
        }
        toast = Toast.makeText(this, "Equation Cleared", Toast.LENGTH_SHORT);
        toast.show();
        InputMethodManager imm = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
        imm.showSoftInput(LHSEqn, InputMethodManager.SHOW_IMPLICIT);
    }
    public void addPlus(View view) {
        EditText LHSEqn = (EditText) findViewById(R.id.leftEquation);
        EditText RHSEqn = (EditText) findViewById(R.id.rightEquation);
        if (LHSEqn.hasFocus()){
            LHSEqn.getText().insert(LHSEqn.getSelectionStart(), "+");
            InputMethodManager imm = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
            imm.showSoftInput(LHSEqn, InputMethodManager.SHOW_IMPLICIT);
        }
        if (RHSEqn.hasFocus()){
            RHSEqn.getText().insert(RHSEqn.getSelectionStart(), "+");
            InputMethodManager imm = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
            imm.showSoftInput(RHSEqn, InputMethodManager.SHOW_IMPLICIT);
        }
    }
    public void addParentheses(View view) {
        EditText LHSEqn = (EditText) findViewById(R.id.leftEquation);
        EditText RHSEqn = (EditText) findViewById(R.id.rightEquation);
        if (LHSEqn.hasFocus()){
            LHSEqn.getText().insert(LHSEqn.getSelectionStart(), "()");
            LHSEqn.setSelection(LHSEqn.getSelectionStart() - 1);
            InputMethodManager imm = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
            imm.showSoftInput(LHSEqn, InputMethodManager.SHOW_IMPLICIT);
        }
        if (RHSEqn.hasFocus()){
            RHSEqn.getText().insert(RHSEqn.getSelectionStart(), "()");
            RHSEqn.setSelection(RHSEqn.getSelectionStart() - 1);
            InputMethodManager imm = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
            imm.showSoftInput(RHSEqn, InputMethodManager.SHOW_IMPLICIT);
        }
    }
}
